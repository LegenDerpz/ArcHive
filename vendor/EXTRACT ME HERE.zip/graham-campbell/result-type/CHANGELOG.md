CHANGE LOG
==========


## V1.1.3 (20/07/2024)

* Added support for PHP 8.4


## V1.1.2 (12/11/2023)

* Added support for PHP 8.3


## V1.1.1 (25/02/2023)

* Cleaned up tests


## V1.1 (30/07/2022)

* Added support for PHP 8.2
* Dropped support for PHP <7.2.5


## V1.0.4 (21/11/2021)

* Updated package metadata


## V1.0.3 (17/10/2021)

* Corrected docs


## V1.0.2 (28/08/2021)

* Added support for PHP 8.1


## V1.0.1 (13/04/2020)

* Updated funding information


## V1.0 (21/03/2020)

* Initial release
